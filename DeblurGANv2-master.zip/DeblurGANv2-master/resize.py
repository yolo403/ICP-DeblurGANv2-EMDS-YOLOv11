from PIL import Image
import os

input_folder = r"D:/project/Citrus_data/data/clarity"
output_folder = r"D:\project\Citrus_data\data\data\image"
new_size = (1024, 1024)  # 例如 (800, 600)

os.makedirs(output_folder, exist_ok=True)

for filename in os.listdir(input_folder):
    if filename.endswith((".jpg", ".png", ".jpeg")):
        img = Image.open(os.path.join(input_folder, filename))
        img_resized = img.resize(new_size, Image.Resampling.LANCZOS)  # 高质量缩放
        img_resized.save(os.path.join(output_folder, filename))