from PySide6 import QtWidgets
from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
                            QMetaObject, QObject, QPoint, QRect,
                            QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
                           QFont, QFontDatabase, QGradient, QIcon,
                           QImage, QKeySequence, QLinearGradient, QPainter,
                           QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QLabel, QListView, QMainWindow,
                               QPushButton, QSizePolicy, QStatusBar, QWidget,
                               QFileDialog, QMessageBox)

import cv2
from ultralytics import YOLO
import os
import time
from threading import Thread
from collections import defaultdict
import datetime

# 导入DeblurGANV2相关模块
import torch
import yaml
import numpy as np
from models.networks import get_generator
from aug import get_normalize


class DeblurGANPredictor:
    def __init__(self, weights_path: str):
        # 加载配置文件
        with open('config/config.yaml', 'r', encoding='utf-8') as cfg:
            config = yaml.load(cfg, Loader=yaml.FullLoader)

        # 获取模型
        model = get_generator(config['model'])

        # 加载训练好的权重
        model.load_state_dict(torch.load(weights_path, map_location='cpu')['model'])

        # 使用GPU如果可用
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        self.model = model.to(self.device)
        self.model.eval()  # 设置为评估模式

        self.normalize_fn = get_normalize()

    @staticmethod
    def _array_to_batch(x):
        x = np.transpose(x, (2, 0, 1))
        x = np.expand_dims(x, 0)
        return torch.from_numpy(x)

    def _preprocess(self, x: np.ndarray):
        x, _ = self.normalize_fn(x, x)

        h, w, _ = x.shape
        block_size = 32
        min_height = (h // block_size + 1) * block_size
        min_width = (w // block_size + 1) * block_size

        pad_params = {
            'mode': 'constant',
            'constant_values': 0,
            'pad_width': ((0, min_height - h), (0, min_width - w), (0, 0))
        }
        x = np.pad(x, **pad_params)

        return self._array_to_batch(x), h, w

    @staticmethod
    def _postprocess(x: torch.Tensor, h: int, w: int) -> np.ndarray:
        x = x.detach().cpu().float().numpy()
        x = np.transpose(x, (0, 2, 3, 1))[0]
        x = (x + 1) / 2.0 * 255.0
        return x.astype('uint8')[:h, :w, :]

    def predict(self, img: np.ndarray) -> np.ndarray:
        """对单张图像进行去模糊预测"""
        img_tensor, h, w = self._preprocess(img)

        with torch.no_grad():
            img_tensor = img_tensor.to(self.device)
            pred = self.model(img_tensor)

        return self._postprocess(pred, h, w)


class MainWindow(QMainWindow):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setupUi(self)
        self.retranslateUi(self)
        self.model = None  # 存储加载的模型
        self.current_image = None  # 当前处理的图像
        self.video_capture = None  # 视频捕获对象
        self.camera_capture = None  # 摄像头捕获对象
        self.is_video_running = False  # 视频是否正在运行
        self.is_camera_running = False  # 摄像头是否正在运行
        self.class_names = {0: '柑橘小果', 1: '柑橘花朵'}  # 类别名称映射
        self.current_results = None  # 当前检测结果
        self.output_dir = "detection_results"  # 检测结果保存目录
        os.makedirs(self.output_dir, exist_ok=True)  # 创建输出目录
        self.deblur_model = None  # DeblurGANV2模型

    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1263, 609)
        MainWindow.setStyleSheet(u"")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.title = QLabel(self.centralwidget)
        self.title.setObjectName(u"title")
        self.title.setGeometry(QRect(-10, 10, 1271, 61))
        self.select_model = QPushButton(self.centralwidget)
        self.select_model.setObjectName(u"select_model")
        self.select_model.setGeometry(QRect(0, 80, 141, 51))
        self.select_model.setStyleSheet(u"background-color: rgb(170, 255, 0);")
        self.image_detection = QPushButton(self.centralwidget)
        self.image_detection.setObjectName(u"image_detection")
        self.image_detection.setGeometry(QRect(0, 140, 141, 51))
        self.image_detection.setStyleSheet(u"background-color: rgb(170, 170, 255);")
        self.batch_detection = QPushButton(self.centralwidget)
        self.batch_detection.setObjectName(u"batch_detection")
        self.batch_detection.setGeometry(QRect(0, 200, 141, 51))
        self.batch_detection.setStyleSheet(u"background-color: rgb(255, 170, 127);")
        self.camera_detection = QPushButton(self.centralwidget)
        self.camera_detection.setObjectName(u"camera_detection")
        self.camera_detection.setGeometry(QRect(0, 320, 141, 51))
        self.camera_detection.setStyleSheet(u"background-color: rgb(0, 170, 255);")
        self.video_detection = QPushButton(self.centralwidget)
        self.video_detection.setObjectName(u"video_detection")
        self.video_detection.setGeometry(QRect(0, 260, 141, 51))
        self.video_detection.setStyleSheet(u"background-color: rgb(85, 170, 127);")
        self.target_count = QPushButton(self.centralwidget)
        self.target_count.setObjectName(u"target_count")
        self.target_count.setGeometry(QRect(0, 380, 141, 51))
        self.target_count.setStyleSheet(u"background-color: rgb(255, 255, 127);")
        self.original_display = QLabel(self.centralwidget)
        self.original_display.setObjectName(u"original_display")
        self.original_display.setGeometry(QRect(160, 100, 401, 381))
        self.results_show = QLabel(self.centralwidget)
        self.results_show.setObjectName(u"results_show")
        self.results_show.setGeometry(QRect(580, 100, 411, 381))
        self.count_results_2 = QLabel(self.centralwidget)
        self.count_results_2.setObjectName(u"count_results_2")
        self.count_results_2.setGeometry(QRect(1020, 100, 241, 381))
        self.original_image = QLabel(self.centralwidget)
        self.original_image.setObjectName(u"original_image")
        self.original_image.setGeometry(QRect(240, 490, 271, 61))
        self.original_image.setStyleSheet(u"background-color: rgb(0, 255, 255);")
        self.detection_results = QLabel(self.centralwidget)
        self.detection_results.setObjectName(u"detection_results")
        self.detection_results.setGeometry(QRect(640, 490, 271, 61))
        self.detection_results.setStyleSheet(u"background-color: rgb(170, 255, 127);")

        # 移除背景图像
        self.listView = QListView(self.centralwidget)
        self.listView.setObjectName(u"listView")
        self.listView.setGeometry(QRect(-40, -10, 1311, 651))

        self.count_results = QLabel(self.centralwidget)
        self.count_results.setObjectName(u"count_results")
        self.count_results.setGeometry(QRect(1020, 490, 241, 61))
        self.count_results.setStyleSheet(u"background-color: rgb(85, 255, 127);")
        self.target_count_2 = QLabel(self.centralwidget)
        self.target_count_2.setObjectName(u"target_count_2")
        self.target_count_2.setGeometry(QRect(1010, 490, 261, 61))
        self.target_count_2.setStyleSheet(u"background-color: rgb(255, 170, 255);")

        # 添加图像去模糊按钮
        self.deblur_image = QPushButton(self.centralwidget)
        self.deblur_image.setObjectName(u"deblur_image")
        self.deblur_image.setGeometry(QRect(0, 440, 141, 51))
        self.deblur_image.setStyleSheet(u"background-color: rgb(170, 255, 255);")

        MainWindow.setCentralWidget(self.centralwidget)
        self.count_results.raise_()
        self.listView.raise_()
        self.title.raise_()
        self.select_model.raise_()
        self.image_detection.raise_()
        self.batch_detection.raise_()
        self.camera_detection.raise_()
        self.video_detection.raise_()
        self.target_count.raise_()
        self.original_display.raise_()
        self.results_show.raise_()
        self.count_results_2.raise_()
        self.original_image.raise_()
        self.detection_results.raise_()
        self.target_count_2.raise_()
        self.deblur_image.raise_()
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        # 连接按钮信号与槽函数
        self.select_model.clicked.connect(self.select_model_file)
        self.image_detection.clicked.connect(self.detect_image)
        self.batch_detection.clicked.connect(self.batch_detect_images)
        self.video_detection.clicked.connect(self.detect_video)
        self.camera_detection.clicked.connect(self.detect_camera)
        self.target_count.clicked.connect(self.count_targets)
        self.deblur_image.clicked.connect(self.deblur_image_func)
        self.retranslateUi(MainWindow)
        QMetaObject.connectSlotsByName(MainWindow)

    def load_deblur_model(self):
        """加载DeblurGANV2模型"""
        try:
            weights_path = "best_fpn.h5"  # 您训练好的模型权重文件
            if not os.path.exists(weights_path):
                QMessageBox.warning(None, "警告", f"找不到DeblurGANV2模型文件: {weights_path}")
                return False

            self.deblur_model = DeblurGANPredictor(weights_path)
            return True
        except Exception as e:
            QMessageBox.warning(None, "错误", f"加载DeblurGANV2模型失败: {str(e)}")
            return False

    def deblur_image_func(self):
        """使用DeblurGANV2进行图像去模糊"""
        if not hasattr(self, 'current_image') or self.current_image is None:
            QMessageBox.warning(None, "警告", "请先选择并检测一张图片！")
            return

        # 加载模型（如果尚未加载）
        if self.deblur_model is None:
            if not self.load_deblur_model():
                return

        try:
            # 确保图像是RGB格式
            if len(self.current_image.shape) == 3 and self.current_image.shape[2] == 3:
                input_image = self.current_image
            else:
                # 如果是灰度图，转换为RGB
                input_image = cv2.cvtColor(self.current_image, cv2.COLOR_GRAY2RGB)

            # 使用DeblurGANV2进行去模糊
            deblurred = self.deblur_model.predict(input_image)

            # 转换为RGB格式显示
            deblurred_rgb = cv2.cvtColor(deblurred, cv2.COLOR_BGR2RGB)

            # 显示去模糊结果
            self.display_numpy_image(deblurred_rgb, self.results_show)
            self.detection_results.setText("DeblurGANV2去模糊结果")

            # 保存去模糊后的图像
            output_path = os.path.join(self.output_dir, f"deblurred_{int(time.time())}.jpg")
            cv2.imwrite(output_path, cv2.cvtColor(deblurred, cv2.COLOR_RGB2BGR))

            QMessageBox.information(None, "成功", f"图像去模糊完成，结果已保存到: {output_path}")

        except Exception as e:
            QMessageBox.warning(None, "错误", f"图像去模糊失败: {str(e)}")

    def select_model_file(self):
        """选择模型文件"""
        model_path, _ = QFileDialog.getOpenFileName(None, '选择模型', '', 'Model files (*.pt *.pth)')
        if model_path:
            try:
                if model_path.endswith('.pt'):
                    self.model = YOLO(model_path)  # 加载 YOLO 模型
                    # 测试模型是否能正常推理
                    test_result = self.model.predict(
                        source=r'C:/Users/30477/Desktop/基于YOLOv11的柑橘花朵和小果检测/51_clarity.png', save=False,
                        verbose=False)
                    if test_result:
                        self.select_model.setText(model_path.split('/')[-1])  # 更新按钮文本
                        QMessageBox.information(None, "成功", "模型加载成功！")
                    else:
                        self.model = None
                        QMessageBox.warning(None, "错误", "模型加载失败，请检查模型文件！")
            except Exception as e:
                self.model = None
                QMessageBox.warning(None, "错误", f"模型加载失败: {str(e)}")

    def detect_image(self):
        """单张图片检测"""
        if not self.model:
            QMessageBox.warning(None, "警告", "请先选择模型文件！")
            return

        # 停止摄像头检测（如果正在运行）
        if self.is_camera_running:
            self.is_camera_running = False
            if self.camera_capture is not None:
                self.camera_capture.release()
            self.camera_detection.setText("摄像头检测")
            self.detection_results.setText("摄像头检测已停止")

        image_path, _ = QFileDialog.getOpenFileName(None, '选择图片', '', 'Image files (*.jpg *.jpeg *.png *.bmp)')
        if image_path:
            # 读取并保存当前图像
            self.current_image = cv2.imread(image_path)

            # 显示原始图片
            self.display_image(image_path, self.original_display)
            self.original_image.setText(os.path.basename(image_path))

            # 进行检测
            results = self.model.predict(source=image_path)

            # 显示检测结果
            if results:
                # 绘制检测结果
                res_plotted = results[0].plot()
                res_plotted = cv2.cvtColor(res_plotted, cv2.COLOR_BGR2RGB)
                self.display_numpy_image(res_plotted, self.results_show)

                # 保存当前结果但不显示计数
                self.current_results = results[0]
            else:
                QMessageBox.warning(None, "警告", "未检测到目标！")

    def detect_camera(self):
        """摄像头检测"""
        if not self.model:
            QMessageBox.warning(None, "警告", "请先选择模型文件！")
            return

        if self.is_camera_running:
            self.is_camera_running = False
            if self.camera_capture is not None:
                self.camera_capture.release()
            self.camera_detection.setText("摄像头检测")
            self.detection_results.setText("摄像头检测已停止")
            return

        # 尝试打开默认摄像头
        self.camera_capture = cv2.VideoCapture(0)
        if not self.camera_capture.isOpened():
            QMessageBox.warning(None, "错误", "无法打开摄像头！")
            return

        self.is_camera_running = True
        self.camera_detection.setText("停止检测")
        self.original_image.setText("摄像头实时画面")
        self.detection_results.setText("摄像头检测中...")

        # 在新线程中处理摄像头帧
        Thread(target=self.process_camera, daemon=True).start()

    def process_camera(self):
        """处理摄像头帧"""
        while self.is_camera_running:
            ret, frame = self.camera_capture.read()
            if not ret:
                self.is_camera_running = False
                self.camera_detection.setText("摄像头检测")
                self.detection_results.setText("摄像头检测失败")
                break

            # 保存当前帧
            self.current_image = frame.copy()

            # 显示原始帧
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            self.display_numpy_image(frame_rgb, self.original_display)

            # 进行检测
            results = self.model.predict(source=frame)

            if results:
                # 绘制检测结果
                res_plotted = results[0].plot()
                res_plotted = cv2.cvtColor(res_plotted, cv2.COLOR_BGR2RGB)
                self.display_numpy_image(res_plotted, self.results_show)

                # 保存当前结果
                self.current_results = results[0]

            # 控制帧率
            time.sleep(0.03)  # 大约30fps

    def batch_detect_images(self):
        """批量图片检测"""
        if not self.model:
            QMessageBox.warning(None, "警告", "请先选择模型文件！")
            return

        dir_path = QFileDialog.getExistingDirectory(None, '选择图片文件夹')
        if dir_path:
            # 获取文件夹中所有图片文件
            image_files = [f for f in os.listdir(dir_path) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))]
            if not image_files:
                QMessageBox.warning(None, "警告", "文件夹中没有图片文件！")
                return

            # 创建结果子目录
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            output_subdir = os.path.join(self.output_dir, f"batch_result_{timestamp}")
            os.makedirs(output_subdir, exist_ok=True)

            # 处理第一张图片并显示
            first_image_path = os.path.join(dir_path, image_files[0])
            self.display_image(first_image_path, self.original_display)
            self.original_image.setText(os.path.basename(first_image_path))

            # 批量处理所有图片
            for i, image_file in enumerate(image_files):
                image_path = os.path.join(dir_path, image_file)

                # 进行检测
                results = self.model.predict(source=image_path)

                if results:
                    # 绘制检测结果
                    res_plotted = results[0].plot()
                    res_plotted = cv2.cvtColor(res_plotted, cv2.COLOR_BGR2RGB)

                    # 如果是第一张图片，显示结果
                    if i == 0:
                        self.display_numpy_image(res_plotted, self.results_show)
                        self.detection_results.setText("批量检测中...")
                        self.current_results = results[0]

                    # 保存结果图片
                    output_path = os.path.join(output_subdir, f"detected_{image_file}")
                    cv2.imwrite(output_path, cv2.cvtColor(res_plotted, cv2.COLOR_RGB2BGR))

                    # 打印检测记录
                    print(f"已处理: {image_file} -> 保存到: {output_path}")

                # 更新进度
                self.detection_results.setText(f"处理中: {i + 1}/{len(image_files)}")
                QApplication.processEvents()  # 更新UI

            self.detection_results.setText("批量检测完成")
            QMessageBox.information(None, "完成", f"已处理{len(image_files)}张图片，结果保存在: {output_subdir}")

    def detect_video(self):
        """视频检测"""
        if not self.model:
            QMessageBox.warning(None, "警告", "请先选择模型文件！")
            return

        if self.is_video_running:
            self.is_video_running = False
            if self.video_capture is not None:
                self.video_capture.release()
            self.video_detection.setText("视频检测")
            return

        video_path, _ = QFileDialog.getOpenFileName(None, '选择视频文件', '', 'Video files (*.mp4 *.avi *.mov)')
        if video_path:
            self.video_capture = cv2.VideoCapture(video_path)
            if not self.video_capture.isOpened():
                QMessageBox.warning(None, "错误", "无法打开视频文件！")
                return

            self.is_video_running = True
            self.video_detection.setText("停止检测")
            self.original_image.setText(os.path.basename(video_path))
            self.detection_results.setText("视频检测中...")

            # 在新线程中处理视频
            Thread(target=self.process_video, daemon=True).start()

    def process_video(self):
        """处理视频帧"""
        while self.is_video_running:
            ret, frame = self.video_capture.read()
            if not ret:
                self.is_video_running = False
                self.video_detection.setText("视频检测")
                self.detection_results.setText("视频检测完成")
                break

            # 保存当前帧
            self.current_image = frame.copy()

            # 显示原始帧
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            self.display_numpy_image(frame_rgb, self.original_display)

            # 进行检测
            results = self.model.predict(source=frame)

            if results:
                # 绘制检测结果
                res_plotted = results[0].plot()
                res_plotted = cv2.cvtColor(res_plotted, cv2.COLOR_BGR2RGB)
                self.display_numpy_image(res_plotted, self.results_show)

                # 保存当前结果
                self.current_results = results[0]

            # 控制帧率
            time.sleep(0.03)  # 大约30fps

    def count_targets(self):
        """目标计数"""
        if not hasattr(self, 'current_results') or self.current_results is None:
            QMessageBox.warning(None, "警告", "请先进行检测！")
            return

        # 更新计数结果
        self.update_count_results(self.current_results)

    def update_count_results(self, results):
        """更新计数结果"""
        # 统计各类别数量
        counts = defaultdict(int)
        for box in results.boxes:
            class_id = int(box.cls)
            counts[class_id] += 1

        # 显示计数结果
        count_text = ""
        for class_id, count in counts.items():
            class_name = self.class_names.get(class_id, f"类别{class_id}")
            count_text += f"{class_name}: {count}个\n"

        if not count_text:
            count_text = "未检测到目标"

        self.count_results_2.setText(
            f"<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; color:#ffaaff;\">{count_text}</span></p></body></html>")

        # 打印到控制台
        print("目标计数结果:")
        print(count_text)

    def display_image(self, image_path, label):
        """显示图片文件"""
        pixmap = QPixmap(image_path)
        # 修改为固定400x500大小
        scaled_pixmap = pixmap.scaled(400, 500, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        # 居中显示
        label.setAlignment(Qt.AlignCenter)
        label.setPixmap(scaled_pixmap)

    def display_numpy_image(self, numpy_image, label):
        """显示numpy数组图像"""
        h, w, ch = numpy_image.shape
        bytes_per_line = ch * w
        q_img = QImage(numpy_image.data, w, h, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(q_img)
        # 修改为固定400x500大小
        scaled_pixmap = pixmap.scaled(400, 500, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        # 居中显示
        label.setAlignment(Qt.AlignCenter)
        label.setPixmap(scaled_pixmap)

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow",
                                                             u"\u67d1\u6a58\u82b1\u6735\u4e0e\u5c0f\u679c\u68c0\u6d4b\u7cfb\u7edf",
                                                             None))
        self.title.setText(QCoreApplication.translate("MainWindow",
                                                      u"<html><head/><body><p align=\"center\"><span style=\" font-size:20pt; font-weight:700; font-style:italic; color:#00ffff;\">基于改进YOLOv11的柑橘花果去模糊检测</span></p></body></html>",
                                                      None))
        self.select_model.setText(QCoreApplication.translate("MainWindow", u"\u9009\u62e9\u6a21\u578b", None))
        self.image_detection.setText(QCoreApplication.translate("MainWindow", u"\u56fe\u7247\u68c0\u6d4b", None))
        self.batch_detection.setText(QCoreApplication.translate("MainWindow", u"\u6279\u91cf\u68c0\u6d4b", None))
        self.camera_detection.setText(QCoreApplication.translate("MainWindow", u"\u6444\u50cf\u5934\u68c0\u6d4b", None))
        self.video_detection.setText(QCoreApplication.translate("MainWindow", u"\u89c6\u9891\u68c0\u6d4b", None))
        self.target_count.setText(QCoreApplication.translate("MainWindow", u"\u76ee\u6807\u8ba1\u6570", None))
        self.original_display.setText(QCoreApplication.translate("MainWindow",
                                                                 u"<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; color:#ff007f;\">\u539f\u59cb\u56fe\u7247</span></p></body></html>",
                                                                 None))
        self.results_show.setText(QCoreApplication.translate("MainWindow",
                                                             u"<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; color:#ff5500;\">\u68c0\u6d4b\u7ed3\u679c</span></p></body></html>",
                                                             None))
        self.count_results_2.setText(QCoreApplication.translate("MainWindow",
                                                                u"<html><head/><body><p align=\"center\"><span style=\" font-size:12pt; font-weight:700; color:#ffaaff;\">\u76ee\u6807\u8ba1\u6570\u7ed3\u679c\u7edf\u8ba1</span></p></body></html>",
                                                                None))
        self.original_image.setText(QCoreApplication.translate("MainWindow",
                                                               u"<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; color:#ff007f;\">\u539f\u59cb\u56fe\u50cf</span></p></body></html>",
                                                               None))
        self.detection_results.setText(QCoreApplication.translate("MainWindow",
                                                                  u"<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; color:#ff557f;\">\u68c0\u6d4b\u7ed3\u679c</span></p></body></html>",
                                                                  None))
        self.count_results.setText(QCoreApplication.translate("MainWindow",
                                                              u"<html><head/><body><p align=\"center\"><span style=\" font-size:16pt; color:#ffaaff;\">\u8ba1\u6570\u7ed3\u679c</span></p></body></html>",
                                                              None))
        self.target_count_2.setText(QCoreApplication.translate("MainWindow",
                                                               u"<html><head/><body><p align=\"center\"><span style=\" font-size:14pt; color:#55ffff;\">\u8ba1\u6570\u7ed3\u679c</span></p></body></html>",
                                                               None))
        self.deblur_image.setText(QCoreApplication.translate("MainWindow", u"\u56fe\u50cf\u53bb\u6a21\u7cca", None))


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    widget = QMainWindow()
    ui = MainWindow()
    ui.setupUi(widget)
    widget.show()
    sys.exit(app.exec())