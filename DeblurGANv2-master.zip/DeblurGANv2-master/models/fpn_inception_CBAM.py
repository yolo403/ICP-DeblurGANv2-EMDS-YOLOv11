import torch
import torch.nn as nn
import torch.nn.functional as F
from pretrainedmodels import inceptionresnetv2


class CBAM(nn.Module):
    def __init__(self, channels, reduction_ratio=16, kernel_size=7):
        super(CBAM, self).__init__()
        # 通道注意力
        self.channel_attention = ChannelAttention(channels, reduction_ratio)
        # 空间注意力
        self.spatial_attention = SpatialAttention(kernel_size)

    def forward(self, x):
        x_out = self.channel_attention(x) * x
        x_out = self.spatial_attention(x_out) * x_out
        return x_out


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc = nn.Sequential(
            nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        assert kernel_size in (3, 7), "kernel size must be 3 or 7"
        padding = 3 if kernel_size == 7 else 1

        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv(x)
        return self.sigmoid(x)


class FPN(nn.Module):
    def __init__(self, norm_layer, num_filters=256):
        super().__init__()
        self.inception = inceptionresnetv2(num_classes=1001, pretrained=False)
        weight_path = 'D:/project/Citrus_data/code/DeblurGANv2-master/weights/inceptionresnetv2.pth'
        state_dict = torch.load(weight_path)
        self.inception.load_state_dict(state_dict)

        # Encoder blocks
        self.enc0 = self.inception.conv2d_1a
        self.enc1 = nn.Sequential(
            self.inception.conv2d_2a,
            self.inception.conv2d_2b,
            self.inception.maxpool_3a,
        )
        self.enc2 = nn.Sequential(
            self.inception.conv2d_3b,
            self.inception.conv2d_4a,
            self.inception.maxpool_5a,
        )
        self.enc3 = nn.Sequential(
            self.inception.mixed_5b,
            self.inception.repeat,
            self.inception.mixed_6a,
        )
        self.enc4 = nn.Sequential(
            self.inception.repeat_1,
            self.inception.mixed_7a,
        )

        # Lateral connections with CBAM
        self.lateral4 = self._build_lateral(2080, num_filters)
        self.lateral3 = self._build_lateral(1088, num_filters)
        self.lateral2 = self._build_lateral(192, num_filters)
        self.lateral1 = self._build_lateral(64, num_filters)
        self.lateral0 = self._build_lateral(32, num_filters // 2)

        # Top-down pathway with CBAM
        self.td1 = self._build_td_block(num_filters)
        self.td2 = self._build_td_block(num_filters)
        self.td3 = self._build_td_block(num_filters)

        self.pad = nn.ReflectionPad2d(1)

        # Freeze backbone initially
        for param in self.inception.parameters():
            param.requires_grad = False

    def _build_lateral(self, in_ch, out_ch):
        return nn.Sequential(
            nn.Conv2d(in_ch, out_ch, kernel_size=1, bias=False),
            CBAM(out_ch)  # 横向连接后立即增强特征
        )

    def _build_td_block(self, channels):
        return nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1),
            nn.BatchNorm2d(channels),
            nn.ReLU(inplace=True),
            CBAM(channels)  # 特征融合后增强
        )

    def unfreeze(self):
        for param in self.inception.parameters():
            param.requires_grad = True

    def forward(self, x):
        # Bottom-up pathway
        enc0 = self.enc0(x)
        enc1 = self.enc1(enc0)
        enc2 = self.enc2(enc1)
        enc3 = self.enc3(enc2)
        enc4 = self.enc4(enc3)

        # Lateral connections
        lateral4 = self.pad(self.lateral4(enc4))
        lateral3 = self.pad(self.lateral3(enc3))
        lateral2 = self.lateral2(enc2)
        lateral1 = self.pad(self.lateral1(enc1))
        lateral0 = self.lateral0(enc0)

        # Top-down pathway
        pad = (1, 2, 1, 2)
        pad1 = (0, 1, 0, 1)
        map4 = lateral4
        map3 = self.td1(lateral3 + F.interpolate(map4, scale_factor=2, mode="nearest"))
        map2 = self.td2(F.pad(lateral2, pad, "reflect") + F.interpolate(map3, scale_factor=2, mode="nearest"))
        map1 = self.td3(lateral1 + F.interpolate(map2, scale_factor=2, mode="nearest"))

        return F.pad(lateral0, pad1, "reflect"), map1, map2, map3, map4


class FPNInception_CBAM(nn.Module):
    def __init__(self, norm_layer=nn.BatchNorm2d, output_ch=3, num_filters=128, num_filters_fpn=256):
        super().__init__()
        self.fpn = FPN(norm_layer=norm_layer, num_filters=num_filters_fpn)

        # Segmentation heads
        self.head1 = nn.Sequential(
            nn.Conv2d(num_filters_fpn, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(),
            CBAM(num_filters)  # 每个head后添加CBAM
        )
        self.head2 = nn.Sequential(
            nn.Conv2d(num_filters_fpn, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(),
            CBAM(num_filters)
        )
        self.head3 = nn.Sequential(
            nn.Conv2d(num_filters_fpn, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(),
            CBAM(num_filters)
        )
        self.head4 = nn.Sequential(
            nn.Conv2d(num_filters_fpn, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(),
            CBAM(num_filters)
        )

        # Smoothing layers
        self.smooth = nn.Sequential(
            nn.Conv2d(4 * num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(),
            CBAM(num_filters)  # 融合后增强
        )

        self.smooth2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters // 2, 3, padding=1),
            norm_layer(num_filters // 2),
            nn.ReLU()
        )

        self.final = nn.Conv2d(num_filters // 2, output_ch, 3, padding=1)

    def forward(self, x):
        # FPN features
        map0, map1, map2, map3, map4 = self.fpn(x)

        # Upsample and concat
        map4 = F.interpolate(self.head4(map4), scale_factor=8, mode="nearest")
        map3 = F.interpolate(self.head3(map3), scale_factor=4, mode="nearest")
        map2 = F.interpolate(self.head2(map2), scale_factor=2, mode="nearest")
        map1 = F.interpolate(self.head1(map1), scale_factor=1, mode="nearest")

        # Feature fusion
        smoothed = self.smooth(torch.cat([map4, map3, map2, map1], dim=1))
        smoothed = F.interpolate(smoothed, scale_factor=2, mode="nearest")
        smoothed = self.smooth2(smoothed + map0)
        smoothed = F.interpolate(smoothed, scale_factor=2, mode="nearest")

        # Final output
        final = self.final(smoothed)
        res = torch.tanh(final) + x
        return torch.clamp(res, min=-1, max=1)

    def freeze(self):
        for param in self.parameters():
            param.requires_grad = False

    def unfreeze(self):
        for param in self.parameters():
            param.requires_grad = True


if __name__ == '__main__':
    model = FPNInception_CBAM()
    input_tensor = torch.randn(1, 3, 256, 256)
    output = model(input_tensor)
    print(f"Input shape: {input_tensor.shape}")
    print(f"Output shape: {output.shape}")
    print("Total CBAM modules:", sum(1 for m in model.modules() if isinstance(m, CBAM)))
