import torch
import torch.nn as nn
import torch.nn.functional as F
from pretrainedmodels import inceptionresnetv2
import math


class FPNHead(nn.Module):
    def __init__(self, num_in, num_mid, num_out, norm_layer):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(num_in, num_mid, 3, padding=1, bias=False),
            norm_layer(num_mid),
            nn.ReLU(inplace=True),
            nn.Conv2d(num_mid, num_out, 3, padding=1, bias=False),
            norm_layer(num_out),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.block(x)


class BiFPN(nn.Module):
    def __init__(self, norm_layer, num_filters=256, epsilon=1e-4, weight_path=None):
        super().__init__()
        self.epsilon = epsilon
        self.num_filters = num_filters

        # 主干网络
        self.inception = inceptionresnetv2(num_classes=1001, pretrained=False)

        if weight_path:
            try:
                state_dict = torch.load(weight_path)
                self.inception.load_state_dict(state_dict)
            except Exception as e:
                print(f"权重加载失败: {str(e)}")

        # 编码器模块
        self.enc0 = self.inception.conv2d_1a
        self.enc1 = nn.Sequential(
            self.inception.conv2d_2a,
            self.inception.conv2d_2b,
            self.inception.maxpool_3a,
        )
        self.enc2 = nn.Sequential(
            self.inception.conv2d_3b,
            self.inception.conv2d_4a,
            self.inception.maxpool_5a,
        )
        self.enc3 = nn.Sequential(
            self.inception.mixed_5b,
            self.inception.repeat,
            self.inception.mixed_6a,
        )
        self.enc4 = nn.Sequential(
            self.inception.repeat_1,
            self.inception.mixed_7a,
        )

        # 横向连接
        self.lateral_convs = nn.ModuleList([
            nn.Conv2d(32, num_filters // 2, 1, bias=False),
            nn.Conv2d(64, num_filters, 1, bias=False),
            nn.Conv2d(192, num_filters, 1, bias=False),
            nn.Conv2d(1088, num_filters, 1, bias=False),
            nn.Conv2d(2080, num_filters, 1, bias=False)
        ])

        # 特征融合卷积
        self.conv4 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1, bias=False),
            norm_layer(num_filters),
            nn.ReLU(inplace=True)
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1, bias=False),
            norm_layer(num_filters),
            nn.ReLU(inplace=True)
        )
        self.conv2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1, bias=False),
            norm_layer(num_filters),
            nn.ReLU(inplace=True)
        )
        self.conv1 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1, bias=False),
            norm_layer(num_filters),
            nn.ReLU(inplace=True)
        )

        # 冻结主干
        for param in self.inception.parameters():
            param.requires_grad = False

    def _resize(self, x, size):
        """精确调整特征图尺寸"""
        if x.shape[2:] == size:
            return x
        return F.interpolate(x, size=size, mode='bilinear', align_corners=False)

    def forward(self, x):
        # 自下而上路径
        f0 = self.enc0(x)  # 1/1
        f1 = self.enc1(f0)  # 1/2
        f2 = self.enc2(f1)  # 1/4
        f3 = self.enc3(f2)  # 1/8
        f4 = self.enc4(f3)  # 1/16

        # 横向连接
        p0 = self.lateral_convs[0](f0)  # 1/1
        p1 = self.lateral_convs[1](f1)  # 1/2
        p2 = self.lateral_convs[2](f2)  # 1/4
        p3 = self.lateral_convs[3](f3)  # 1/8
        p4 = self.lateral_convs[4](f4)  # 1/16

        # 自上而下路径
        p4_up = self._resize(p4, p3.shape[2:])
        p3 = self.conv4(p3 + p4_up)

        p3_up = self._resize(p3, p2.shape[2:])
        p2 = self.conv3(p2 + p3_up)

        p2_up = self._resize(p2, p1.shape[2:])
        p1 = self.conv2(p1 + p2_up)

        # 自下而上路径
        p1_down = F.max_pool2d(p1, 2)
        p2 = self.conv1(p2 + self._resize(p1_down, p2.shape[2:]))

        p2_down = F.max_pool2d(p2, 2)
        p3 = p3 + self._resize(p2_down, p3.shape[2:])

        p3_down = F.max_pool2d(p3, 2)
        p4 = p4 + self._resize(p3_down, p4.shape[2:])

        return [p0, p1, p2, p3, p4]


class FPNInception_BiFPN(nn.Module):
    def __init__(self, norm_layer, output_ch=3, num_filters=128, num_filters_fpn=256, weight_path=None):
        super().__init__()
        self.fpn = BiFPN(norm_layer, num_filters_fpn, weight_path=weight_path)

        # 特征头
        self.heads = nn.ModuleList([
            FPNHead(num_filters_fpn, num_filters, num_filters, norm_layer)
            for _ in range(4)
        ])

        # 平滑层
        self.smooth = nn.Sequential(
            nn.Conv2d(4 * num_filters, num_filters, 3, padding=1, bias=False),
            norm_layer(num_filters),
            nn.ReLU(inplace=True)
        )

        self.smooth2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters // 2, 3, padding=1, bias=False),
            norm_layer(num_filters // 2),
            nn.ReLU(inplace=True)
        )

        # 输出层
        self.final = nn.Conv2d(num_filters // 2, output_ch, 3, padding=1)

    def forward(self, x):
        # 获取特征
        features = self.fpn(x)
        p0, p1, p2, p3, p4 = features
        target_size = x.shape[2:]

        # 处理各层特征
        processed = []
        for i, (head, feat) in enumerate(zip(self.heads, [p4, p3, p2, p1])):
            feat_resized = F.interpolate(
                head(feat),
                size=target_size,
                mode='bilinear',
                align_corners=False
            )
            processed.append(feat_resized)

        # 特征融合
        combined = torch.cat(processed, dim=1)
        smoothed = self.smooth(combined)

        # 处理p0
        p0_resized = F.interpolate(
            p0,
            size=target_size,
            mode='bilinear',
            align_corners=False
        )

        smoothed2 = self.smooth2(smoothed + p0_resized)
        output = self.final(smoothed2)

        return torch.clamp(x + output, -1, 1)


def test_model():
    norm_layer = nn.BatchNorm2d
    model = FPNInception_BiFPN(norm_layer)

    # 测试尺寸
    test_sizes = [(256, 256), (288, 288), (512, 512)]  # 确保是32的倍数

    for h, w in test_sizes:
        print(f"\nTesting size: {h}x{w}")
        try:
            x = torch.randn(1, 3, h, w)
            y = model(x)
            assert y.shape == x.shape
            print(f"Success! Input: {x.shape} Output: {y.shape}")
        except Exception as e:
            print(f"Failed: {str(e)}")


if __name__ == "__main__":
    test_model()