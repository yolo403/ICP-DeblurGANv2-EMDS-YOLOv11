import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, in_channel, out_channel, stride=1, downsample=None,
                 groups=1, width_per_group=64, norm_layer=nn.BatchNorm2d):
        super(Bottleneck, self).__init__()
        width = int(out_channel * (width_per_group / 64.)) * groups

        self.conv1 = nn.Conv2d(in_channel, width, kernel_size=1, stride=1, bias=False)
        self.bn1 = norm_layer(width)
        self.conv2 = nn.Conv2d(width, width, groups=groups, kernel_size=3,
                               stride=stride, bias=False, padding=1)
        self.bn2 = norm_layer(width)
        self.conv3 = nn.Conv2d(width, out_channel * self.expansion,
                               kernel_size=1, stride=1, bias=False)
        self.bn3 = norm_layer(out_channel * self.expansion)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample

    def forward(self, x):
        identity = x
        if self.downsample is not None:
            identity = self.downsample(x)

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        out += identity
        out = self.relu(out)
        return out


class ResNet(nn.Module):
    def __init__(self, block, blocks_num, num_classes=1000, include_top=True,
                 groups=1, width_per_group=64, norm_layer=nn.BatchNorm2d):
        super(ResNet, self).__init__()
        self.include_top = include_top
        self.in_channel = 64
        self.groups = groups
        self.width_per_group = width_per_group
        self.norm_layer = norm_layer

        self.conv1 = nn.Conv2d(3, self.in_channel, kernel_size=7, stride=2,
                               padding=3, bias=False)
        self.bn1 = norm_layer(self.in_channel)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer1 = self._make_layer(block, 64, blocks_num[0])
        self.layer2 = self._make_layer(block, 128, blocks_num[1], stride=2)
        self.layer3 = self._make_layer(block, 256, blocks_num[2], stride=2)
        self.layer4 = self._make_layer(block, 512, blocks_num[3], stride=2)

        if self.include_top:
            self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
            self.fc = nn.Linear(512 * block.expansion, num_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')

    def _make_layer(self, block, channel, block_num, stride=1):
        downsample = None
        if stride != 1 or self.in_channel != channel * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.in_channel, channel * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                self.norm_layer(channel * block.expansion))

        layers = []
        layers.append(block(self.in_channel, channel, downsample=downsample,
                            stride=stride, groups=self.groups,
                            width_per_group=self.width_per_group,
                            norm_layer=self.norm_layer))
        self.in_channel = channel * block.expansion

        for _ in range(1, block_num):
            layers.append(block(self.in_channel, channel,
                                groups=self.groups,
                                width_per_group=self.width_per_group,
                                norm_layer=self.norm_layer))

        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        if self.include_top:
            x = self.avgpool(x)
            x = torch.flatten(x, 1)
            x = self.fc(x)

        return x


def resnet101(num_classes=1000, include_top=True, pretrained=True, norm_layer=nn.BatchNorm2d):
    model = ResNet(Bottleneck, [3, 4, 23, 3], num_classes=num_classes,
                   include_top=include_top, norm_layer=norm_layer)
    if pretrained:
        state_dict = torch.hub.load_state_dict_from_url(
            "https://download.pytorch.org/models/resnet101-5d3b4d8f.pth",
            progress=True)
        model.load_state_dict(state_dict, strict=False)
    return model


class PANet(nn.Module):
    def __init__(self, num_filters=256, pretrained=True, norm_layer=nn.BatchNorm2d):
        super().__init__()
        backbone = resnet101(pretrained=pretrained, norm_layer=norm_layer)

        # Bottom-up路径（保持不变）
        self.enc0 = nn.Sequential(
            backbone.conv1, norm_layer(backbone.bn1.num_features),
            backbone.relu, backbone.maxpool)
        self.enc1 = backbone.layer1  # 256
        self.enc2 = backbone.layer2  # 512
        self.enc3 = backbone.layer3  # 1024
        self.enc4 = backbone.layer4  # 2048

        # Top-down路径
        self.lateral4 = nn.Conv2d(2048, num_filters, 1)
        self.lateral3 = nn.Conv2d(1024, num_filters, 1)
        self.lateral2 = nn.Conv2d(512, num_filters, 1)
        self.lateral1 = nn.Conv2d(256, num_filters, 1)

        # Smooth层（保持不变）
        self.smooth4 = nn.Conv2d(num_filters, num_filters, 3, padding=1)
        self.smooth3 = nn.Conv2d(num_filters, num_filters, 3, padding=1)
        self.smooth2 = nn.Conv2d(num_filters, num_filters, 3, padding=1)

        # Bottom-up增强路径（保持不变）
        self.bottom_up_conv1 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, stride=2, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )
        self.bottom_up_conv2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, stride=2, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )
        self.bottom_up_conv3 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, stride=2, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )

    def forward(self, x):
        # Bottom-up路径
        c1 = self.enc0(x)
        c2 = self.enc1(c1)
        c3 = self.enc2(c2)
        c4 = self.enc3(c3)
        c5 = self.enc4(c4)

        # Top-down路径（移除注意力计算）
        p5 = self.lateral4(c5)
        p4 = self.smooth4(F.interpolate(p5, size=c4.shape[-2:]) + self.lateral3(c4))
        p3 = self.smooth3(F.interpolate(p4, size=c3.shape[-2:]) + self.lateral2(c3))
        p2 = self.smooth2(F.interpolate(p3, size=c2.shape[-2:]) + self.lateral1(c2))
        p1 = F.interpolate(p2, size=c1.shape[-2:])

        # Bottom-up增强路径
        n2 = p2
        n3 = self.bottom_up_conv1(n2) + p3
        n4 = self.bottom_up_conv2(n3) + p4
        n5 = self.bottom_up_conv3(n4) + p5

        return p1, n2, n3, n4, n5


class PANetResNet101(nn.Module):
    def __init__(self, output_ch=3, num_filters=128, num_filters_panet=256, norm_layer=nn.BatchNorm2d):
        super().__init__()
        self.panet = PANet(num_filters=num_filters_panet, norm_layer=norm_layer)

        def make_head():
            return nn.Sequential(
                nn.Conv2d(num_filters_panet, num_filters, 3, padding=1),
                norm_layer(num_filters),
                nn.ReLU(),
                nn.Conv2d(num_filters, num_filters, 3, padding=1),
                norm_layer(num_filters),
                nn.ReLU()
            )

        self.head1 = make_head()
        self.head2 = make_head()
        self.head3 = make_head()
        self.head4 = make_head()
        self.head5 = make_head()

        self.smooth = nn.Sequential(
            nn.Conv2d(5 * num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )

        self.final_conv = nn.Sequential(
            nn.Conv2d(num_filters, num_filters // 2, 3, padding=1),
            norm_layer(num_filters // 2),
            nn.ReLU(),
            nn.Conv2d(num_filters // 2, output_ch, 3, padding=1),
            nn.Tanh()
        )

    def forward(self, x):
        p1, p2, p3, p4, p5 = self.panet(x)

        h1 = F.interpolate(self.head1(p1), size=x.shape[-2:], mode='bilinear')
        h2 = F.interpolate(self.head2(p2), size=x.shape[-2:], mode='bilinear')
        h3 = F.interpolate(self.head3(p3), size=x.shape[-2:], mode='bilinear')
        h4 = F.interpolate(self.head4(p4), size=x.shape[-2:], mode='bilinear')
        h5 = F.interpolate(self.head5(p5), size=x.shape[-2:], mode='bilinear')

        fused = torch.cat([h1, h2, h3, h4, h5], dim=1)
        smoothed = self.smooth(fused)
        output = self.final_conv(smoothed) + x
        return torch.clamp(output, -1, 1)

    def freeze(self):
        for param in self.parameters():
            param.requires_grad = False

    def unfreeze(self):
        for param in self.parameters():
            param.requires_grad = True


if __name__ == "__main__":
    # Test the network
    model = PANetResNet101(output_ch=3)
    input_tensor = torch.randn(1, 3, 256, 256)
    output = model(input_tensor)
    print(f"Input shape: {input_tensor.shape}")
    print(f"Output shape: {output.shape}")
    # Calculate parameters
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Total parameters: {total_params / 1e6:.2f}M")
