import torch
import torch.nn as nn
import torch.nn.functional as F
from pretrainedmodels import inceptionresnetv2


class PANet(nn.Module):
    def __init__(self, norm_layer, num_filters=256):
        super().__init__()
        self.inception = inceptionresnetv2(num_classes=1001, pretrained=False)
        weight_path = 'D:/project/Citrus_data/code/DeblurGANv2-master/weights/inceptionresnetv2.pth'
        state_dict = torch.load(weight_path, weights_only=True)
        self.inception.load_state_dict(state_dict)

        # Bottom-up pathway
        self.enc0 = self.inception.conv2d_1a  # 32 channels
        self.enc1 = nn.Sequential(
            self.inception.conv2d_2a,
            self.inception.conv2d_2b,
            self.inception.maxpool_3a,
        )  # 64 channels
        self.enc2 = nn.Sequential(
            self.inception.conv2d_3b,
            self.inception.conv2d_4a,
            self.inception.maxpool_5a,
        )  # 192 channels
        self.enc3 = nn.Sequential(
            self.inception.mixed_5b,
            self.inception.repeat,
            self.inception.mixed_6a,
        )  # 1088 channels
        self.enc4 = nn.Sequential(
            self.inception.repeat_1,
            self.inception.mixed_7a,
        )  # 2080 channels

        # Lateral connections
        self.lateral4 = nn.Conv2d(2080, num_filters, 1)
        self.lateral3 = nn.Conv2d(1088, num_filters, 1)
        self.lateral2 = nn.Conv2d(192, num_filters, 1)
        self.lateral1 = nn.Conv2d(64, num_filters, 1)
        self.lateral0 = nn.Conv2d(32, num_filters, 1)

        # Smooth layers with proper padding
        self.smooth4 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )
        self.smooth3 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )
        self.smooth2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )

        # Bottom-up enhancement pathway with proper stride and padding
        self.bottom_up_conv1 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, stride=2, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )
        self.bottom_up_conv2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, stride=2, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )
        self.bottom_up_conv3 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, stride=2, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )

        # Freeze backbone initially
        for param in self.inception.parameters():
            param.requires_grad = False

    def unfreeze(self):
        for param in self.inception.parameters():
            param.requires_grad = True

    def forward(self, x):
        # Bottom-up pathway
        c0 = self.enc0(x)  # 32 channels
        c1 = self.enc1(c0)  # 64
        c2 = self.enc2(c1)  # 192
        c3 = self.enc3(c2)  # 1088
        c4 = self.enc4(c3)  # 2080

        # Lateral connections
        lateral4 = self.lateral4(c4)  # 2080->256
        lateral3 = self.lateral3(c3)  # 1088->256
        lateral2 = self.lateral2(c2)  # 192->256
        lateral1 = self.lateral1(c1)  # 64->256
        lateral0 = self.lateral0(c0)  # 32->256

        # Top-down pathway with size matching
        p4 = lateral4
        p3 = self.smooth4(F.interpolate(p4, size=c3.shape[-2:], mode='nearest') + lateral3)
        p2 = self.smooth3(F.interpolate(p3, size=c2.shape[-2:], mode='nearest') + lateral2)
        p1 = self.smooth2(F.interpolate(p2, size=c1.shape[-2:], mode='nearest') + lateral1)
        p0 = F.interpolate(p1, size=c0.shape[-2:], mode='nearest') + lateral0

        # Bottom-up enhancement pathway with size matching
        # Ensure all operations maintain spatial dimensions
        n1 = p1
        n2 = self.bottom_up_conv1(n1)
        n2 = F.interpolate(n2, size=p2.shape[-2:], mode='nearest') + p2
        n3 = self.bottom_up_conv2(n2)
        n3 = F.interpolate(n3, size=p3.shape[-2:], mode='nearest') + p3
        n4 = self.bottom_up_conv3(n3)
        n4 = F.interpolate(n4, size=p4.shape[-2:], mode='nearest') + p4

        return p0, n1, n2, n3, n4


class PANetInception(nn.Module):
    def __init__(self, norm_layer, output_ch=3, num_filters=128, num_filters_panet=256):
        super().__init__()
        self.panet = PANet(num_filters=num_filters_panet, norm_layer=norm_layer)

        def make_head():
            return nn.Sequential(
                nn.Conv2d(num_filters_panet, num_filters, 3, padding=1),
                norm_layer(num_filters),
                nn.ReLU(),
                nn.Conv2d(num_filters, num_filters, 3, padding=1),
                norm_layer(num_filters),
                nn.ReLU()
            )

        self.head0 = make_head()
        self.head1 = make_head()
        self.head2 = make_head()
        self.head3 = make_head()
        self.head4 = make_head()

        self.smooth = nn.Sequential(
            nn.Conv2d(5 * num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )

        self.final_conv = nn.Sequential(
            nn.Conv2d(num_filters, num_filters // 2, 3, padding=1),
            norm_layer(num_filters // 2),
            nn.ReLU(),
            nn.Conv2d(num_filters // 2, output_ch, 3, padding=1),
            nn.Tanh()
        )

    def forward(self, x):
        p0, p1, p2, p3, p4 = self.panet(x)

        h0 = F.interpolate(self.head0(p0), size=x.shape[-2:], mode='bilinear')
        h1 = F.interpolate(self.head1(p1), size=x.shape[-2:], mode='bilinear')
        h2 = F.interpolate(self.head2(p2), size=x.shape[-2:], mode='bilinear')
        h3 = F.interpolate(self.head3(p3), size=x.shape[-2:], mode='bilinear')
        h4 = F.interpolate(self.head4(p4), size=x.shape[-2:], mode='bilinear')

        fused = torch.cat([h0, h1, h2, h3, h4], dim=1)
        smoothed = self.smooth(fused)
        output = self.final_conv(smoothed) + x
        return torch.clamp(output, -1, 1)

    def unfreeze(self):
        self.panet.unfreeze()


if __name__ == "__main__":
    # Test the network
    model = PANetInception(norm_layer=nn.BatchNorm2d, output_ch=3)
    input_tensor = torch.randn(1, 3, 256, 256)  # Ensure input size is compatible
    print("Testing with input size:", input_tensor.shape)
    output = model(input_tensor)
    print(f"Input shape: {input_tensor.shape}")
    print(f"Output shape: {output.shape}")
    total_params = sum(p.numel() for p in model.parameters())
    print(f"Total parameters: {total_params / 1e6:.2f}M")