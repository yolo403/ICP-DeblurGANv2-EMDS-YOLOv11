import numpy as np
import torch.nn as nn
from skimage.metrics import structural_similarity as SSIM
from util.metrics import PSNR


class DeblurModel(nn.Module):
    def __init__(self):
        super(DeblurModel, self).__init__()

    def get_input(self, data):
        img = data['a']
        inputs = img
        targets = data['b']
        inputs, targets = inputs.cuda(), targets.cuda()
        return inputs, targets

    def tensor2im(self, image_tensor, imtype=np.uint8):
        image_numpy = image_tensor[0].cpu().float().numpy()
        image_numpy = (np.transpose(image_numpy, (1, 2, 0)) + 1) / 2.0 * 255.0
        return image_numpy.astype(imtype)

    def get_images_and_metrics(self, inp, output, target) -> (float, float, np.ndarray):
        # 转换张量为numpy数组
        inp = self.tensor2im(inp)  # 输入图像 (H,W,C)
        fake = self.tensor2im(output.data)  # 生成图像 (H,W,C)
        real = self.tensor2im(target.data)  # 真实图像 (H,W,C)

        # 计算PSNR
        psnr = PSNR(fake, real)

        # 计算SSIM（带动态窗口大小）
        min_side = min(fake.shape[0], fake.shape[1])  # 获取最小边长
        win_size = min(7, min_side if min_side % 2 == 1 else min_side - 1)  # 确保奇数

        try:
            ssim = SSIM(
                fake,
                real,
                win_size=win_size,
                channel_axis=2,  # 对于HWC格式的图像
                data_range=255,  # 8位图像范围
                multichannel=True  # 兼容新旧版本
            )
        except ValueError as e:
            print(f"SSIM计算失败: {e}")
            print(f"图像尺寸: {fake.shape}, 使用的win_size: {win_size}")
            ssim = 0.0  # 失败时返回默认值

        # 可视化对比图
        vis_img = np.hstack((inp, fake, real))

        return float(psnr), float(ssim), vis_img


def get_model(model_config):
    return DeblurModel()
