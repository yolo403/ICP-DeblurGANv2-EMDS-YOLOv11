import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import OrderedDict
from pretrainedmodels import inceptionresnetv2
from torchsummary import summary


class CBAM(nn.Module):
    def __init__(self, channels, reduction_ratio=16, kernel_size=5):
        super(CBAM, self).__init__()
        # 通道注意力
        self.channel_attention = ChannelAttention(channels, reduction_ratio)
        # 空间注意力
        self.spatial_attention = SpatialAttention(kernel_size)

    def forward(self, x):
        x_out = self.channel_attention(x) * x
        x_out = self.spatial_attention(x_out) * x_out
        return x_out


class ChannelAttention(nn.Module):
    def __init__(self, in_planes, ratio=16):
        super(ChannelAttention, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.max_pool = nn.AdaptiveMaxPool2d(1)

        self.fc = nn.Sequential(
            nn.Conv2d(in_planes, in_planes // ratio, 1, bias=False),
            nn.ReLU(),
            nn.Conv2d(in_planes // ratio, in_planes, 1, bias=False)
        )
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = self.fc(self.avg_pool(x))
        max_out = self.fc(self.max_pool(x))
        out = avg_out + max_out
        return self.sigmoid(out)


class SpatialAttention(nn.Module):
    def __init__(self, kernel_size=7):
        super(SpatialAttention, self).__init__()
        assert kernel_size in (3, 7), "kernel size must be 3 or 7"
        padding = 3 if kernel_size == 7 else 1

        self.conv = nn.Conv2d(2, 1, kernel_size, padding=padding, bias=False)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        avg_out = torch.mean(x, dim=1, keepdim=True)
        max_out, _ = torch.max(x, dim=1, keepdim=True)
        x = torch.cat([avg_out, max_out], dim=1)
        x = self.conv(x)
        return self.sigmoid(x)

# AC-FPN 实现代码

# 实现了CxAM和CnAM模块CxAM
class CxAM(nn.Module):
    def __init__(self, in_channels, out_channels, reduction=8):
        super(CxAM, self).__init__()
        self.key_conv = nn.Conv2d(in_channels, out_channels // reduction, 1)
        self.query_conv = nn.Conv2d(in_channels, out_channels // reduction, 1)
        self.value_conv = nn.Conv2d(in_channels, in_channels, 1)
        self.sigmoid = nn.Sigmoid()
        self.avg = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        m_batchsize, C, width, height = x.size()

        proj_query = self.query_conv(x).view(m_batchsize, -1, width * height).permute(0, 2, 1)  # B x N x C'

        proj_key = self.key_conv(x).view(m_batchsize, -1, width * height)  # B x C' x N

        R = torch.bmm(proj_query, proj_key).view(m_batchsize, width * height, width, height)  # B x N x W x H
        # 先进行全局平均池化, 此时 R 的shape为 B x N x 1 x 1, 再进行view, R 的shape为 B x 1 x W x H
        attention_R = self.sigmoid(self.avg(R).view(m_batchsize, -1, width, height))  # B x 1 x W x H

        proj_value = self.value_conv(x)

        out = proj_value * attention_R  # B x W x H

        return out


class CnAM(nn.Module):
    def __init__(self, in_channels, out_channels, reduction=8):
        super(CnAM, self).__init__()
        # 原文中对应的P, Z, S
        self.Z_conv = nn.Conv2d(in_channels, out_channels // reduction, 1)
        self.P_conv = nn.Conv2d(in_channels, out_channels // reduction, 1)
        self.value_conv = nn.Conv2d(in_channels, in_channels, 1)
        self.sigmoid = nn.Sigmoid()
        self.avg = nn.AdaptiveAvgPool2d(1)

    # CnAM使用了FPN中的F5和CEM输出的特征图F
    def forward(self, F5, F):
        m_batchsize, C, width, height = F5.size()

        proj_query = self.P_conv(F5).view(m_batchsize, -1, width * height).permute(0, 2, 1)  # B x N x C''

        proj_key = self.Z_conv(F5).view(m_batchsize, -1, width * height)  # B x C'' x N

        S = torch.bmm(proj_query, proj_key).view(m_batchsize, width * height, width, height)  # B x N x W x H
        attention_S = self.sigmoid(self.avg(S).view(m_batchsize, -1, width, height))  # B x 1 x W x H

        proj_value = self.value_conv(F)

        out = proj_value * attention_S  # B x W x H

        return out


class DenseBlock(nn.Module):
    def __init__(self, input_num, num1, num2, rate, drop_out):
        super(DenseBlock, self).__init__()

        # C: 2048 --> 512 --> 256
        self.conv1x1 = nn.Conv2d(in_channels=input_num, out_channels=num1, kernel_size=1)
        self.ConvGN = nn.GroupNorm(num_groups=32, num_channels=num1)
        self.relu1 = nn.ReLU(inplace=True)
        self.dilaconv = nn.Conv2d(in_channels=num1, out_channels=num2, kernel_size=3, padding=1 * rate, dilation=rate)
        self.relu2 = nn.ReLU(inplace=True)
        self.drop = nn.Dropout(p=drop_out)

    def forward(self, x):
        x = self.ConvGN(self.conv1x1(x))
        x = self.relu1(x)
        x = self.dilaconv(x)
        x = self.relu2(x)
        x = self.drop(x)
        return x


class DenseAPP(nn.Module):
    def __init__(self, num_channels=2048):
        super(DenseAPP, self).__init__()
        self.drop_out = 0.1
        self.channels1 = 512
        self.channels2 = 256
        self.num_channels = num_channels
        self.aspp3 = DenseBlock(self.num_channels, num1=self.channels1, num2=self.channels2, rate=3,
                                drop_out=self.drop_out)
        self.aspp6 = DenseBlock(self.num_channels + self.channels2 * 1, num1=self.channels1, num2=self.channels2,
                                rate=6,
                                drop_out=self.drop_out)
        self.aspp12 = DenseBlock(self.num_channels + self.channels2 * 2, num1=self.channels1, num2=self.channels2,
                                 rate=12,
                                 drop_out=self.drop_out)
        self.aspp18 = DenseBlock(self.num_channels + self.channels2 * 3, num1=self.channels1, num2=self.channels2,
                                 rate=18,
                                 drop_out=self.drop_out)
        self.aspp24 = DenseBlock(self.num_channels + self.channels2 * 4, num1=self.channels1, num2=self.channels2,
                                 rate=24,
                                 drop_out=self.drop_out)
        self.conv1x1 = nn.Conv2d(in_channels=5 * self.channels2, out_channels=256, kernel_size=1)
        self.ConvGN = nn.GroupNorm(num_groups=32, num_channels=256)
        self.cbam = CBAM(256)  # 添加CBAM

    def forward(self, feature):
        aspp3 = self.aspp3(feature)
        feature = torch.concat((aspp3, feature), dim=1)
        aspp6 = self.aspp6(feature)
        feature = torch.concat((aspp6, feature), dim=1)
        aspp12 = self.aspp12(feature)
        feature = torch.concat((aspp12, feature), dim=1)
        aspp18 = self.aspp18(feature)
        feature = torch.concat((aspp18, feature), dim=1)
        aspp24 = self.aspp24(feature)

        x = torch.concat((aspp3, aspp6, aspp12, aspp18, aspp24), dim=1)
        out = self.ConvGN(self.conv1x1(x))
        out = self.cbam(out)  # 应用CBAM
        return out


class ACFPN(nn.Module):
    def __init__(self, norm_layer, num_filters=256):
        super(ACFPN, self).__init__()

        # Load pretrained InceptionResNetV2
        self.inception = inceptionresnetv2(num_classes=1001, pretrained=False)
        weight_path = 'D:/project/Citrus_data/code/DeblurGANv2-master/weights/inceptionresnetv2.pth'
        state_dict = torch.load(weight_path)
        self.inception.load_state_dict(state_dict)

        # Encoder blocks
        self.enc0 = self.inception.conv2d_1a
        self.enc1 = nn.Sequential(
            self.inception.conv2d_2a,
            self.inception.conv2d_2b,
            self.inception.maxpool_3a,
        )
        self.enc2 = nn.Sequential(
            self.inception.conv2d_3b,
            self.inception.conv2d_4a,
            self.inception.maxpool_5a,
        )
        self.enc3 = nn.Sequential(
            self.inception.mixed_5b,
            self.inception.repeat,
            self.inception.mixed_6a,
        )
        self.enc4 = nn.Sequential(
            self.inception.repeat_1,
            self.inception.mixed_7a,
        )

        # ACFPN specific modules
        self.dense_app = DenseAPP(num_channels=2080)  # enc4 output channels
        self.cxam = CxAM(in_channels=256, out_channels=256)
        self.cnam = CnAM(in_channels=256, out_channels=256)

        # Lateral connections

        self.lateral4 = nn.Sequential(
            nn.Conv2d(2080, num_filters, kernel_size=1, bias=False),
            CBAM(num_filters)
        )
        self.lateral3 = nn.Sequential(
            nn.Conv2d(1088, num_filters, kernel_size=1, bias=False),
            CBAM(num_filters)
        )
        self.lateral2 = nn.Sequential(
            nn.Conv2d(192, num_filters, kernel_size=1, bias=False)
        )
        self.lateral1 = nn.Sequential(
            nn.Conv2d(64, num_filters, kernel_size=1, bias=False)
        )
        self.lateral0 = nn.Sequential(
            nn.Conv2d(32, num_filters // 2, kernel_size=1, bias=False)
        )

        # Top-down blocks
        self.td1 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, kernel_size=3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(inplace=True),
            CBAM(num_filters)
        )
        self.td2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, kernel_size=3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(inplace=True),
            CBAM(num_filters)
        )
        self.td3 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, kernel_size=3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(inplace=True),
            CBAM(num_filters)
        )

        self.pad = nn.ReflectionPad2d(1)

        # Freeze backbone initially
        for param in self.inception.parameters():
            param.requires_grad = False

    def unfreeze(self):
        for param in self.inception.parameters():
            param.requires_grad = True

    def forward(self, x):
        # Bottom-up pathway
        enc0 = self.enc0(x)
        enc1 = self.enc1(enc0)
        enc2 = self.enc2(enc1)
        enc3 = self.enc3(enc2)
        enc4 = self.enc4(enc3)

        # Apply DenseAPP to highest level features
        dense_feat = self.dense_app(enc4)

        # Lateral connections
        lateral4 = self.pad(self.lateral4(enc4))
        lateral3 = self.pad(self.lateral3(enc3))
        lateral2 = self.lateral2(enc2)
        lateral1 = self.pad(self.lateral1(enc1))
        lateral0 = self.lateral0(enc0)

        # Apply attention mechanisms
        cxam_feat = self.cxam(dense_feat)
        cnam_feat = self.cnam(dense_feat, lateral4)
        attn_feat = cxam_feat + cnam_feat

        # Top-down pathway with attention features
        pad = (1, 2, 1, 2)
        pad1 = (0, 1, 0, 1)

        map4 = lateral4 + attn_feat
        map3 = self.td1(lateral3 + F.interpolate(map4, scale_factor=2, mode="nearest"))
        map2 = self.td2(F.pad(lateral2, pad, "reflect") + F.interpolate(map3, scale_factor=2, mode="nearest"))
        map1 = self.td3(lateral1 + F.interpolate(map2, scale_factor=2, mode="nearest"))

        return F.pad(lateral0, pad1, "reflect"), map1, map2, map3, map4


class FPNHead(nn.Module):
    def __init__(self, num_in, num_mid, num_out):
        super().__init__()
        self.block0 = nn.Conv2d(num_in, num_mid, kernel_size=3, padding=1, bias=False)
        self.block1 = nn.Conv2d(num_mid, num_out, kernel_size=3, padding=1, bias=False)
        self.cbam = CBAM(num_out)  # 添加CBAM

    def forward(self, x):
        x = F.relu(self.block0(x), inplace=True)
        x = F.relu(self.block1(x), inplace=True)
        x = self.cbam(x)  # 应用CBAM
        return x


class FPNInception_ACFPN(nn.Module):
    def __init__(self, norm_layer, output_ch=3, num_filters=128, num_filters_fpn=256):
        super().__init__()
        # Replace FPN with ACFPN
        self.fpn = ACFPN(norm_layer=norm_layer, num_filters=num_filters_fpn)

        # Segmentation heads
        self.head1 = FPNHead(num_filters_fpn, num_filters, num_filters)
        self.head2 = FPNHead(num_filters_fpn, num_filters, num_filters)
        self.head3 = FPNHead(num_filters_fpn, num_filters, num_filters)
        self.head4 = FPNHead(num_filters_fpn, num_filters, num_filters)

        self.smooth = nn.Sequential(
            nn.Conv2d(4 * num_filters, num_filters, kernel_size=3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(),
            CBAM(num_filters)
        )

        self.smooth2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters // 2, kernel_size=3, padding=1),
            norm_layer(num_filters // 2),
            nn.ReLU(),
            CBAM(num_filters // 2)
        )

        self.final = nn.Conv2d(num_filters // 2, output_ch, kernel_size=3, padding=1)

    def unfreeze(self):
        self.fpn.unfreeze()

    def forward(self, x):
        map0, map1, map2, map3, map4 = self.fpn(x)

        map4 = F.interpolate(self.head4(map4), scale_factor=8, mode="nearest")
        map3 = F.interpolate(self.head3(map3), scale_factor=4, mode="nearest")
        map2 = F.interpolate(self.head2(map2), scale_factor=2, mode="nearest")
        map1 = F.interpolate(self.head1(map1), scale_factor=1, mode="nearest")

        smoothed = self.smooth(torch.cat([map4, map3, map2, map1], dim=1))
        smoothed = F.interpolate(smoothed, scale_factor=2, mode="nearest")
        smoothed = self.smooth2(smoothed + map0)
        smoothed = F.interpolate(smoothed, scale_factor=2, mode="nearest")

        final = self.final(smoothed)
        res = torch.tanh(final) + x

        return torch.clamp(res, min=-1, max=1)