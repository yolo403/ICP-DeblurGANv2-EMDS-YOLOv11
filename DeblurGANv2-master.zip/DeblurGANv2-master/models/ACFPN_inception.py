import torch
import torch.nn as nn
import torch.nn.functional as F
from collections import OrderedDict
from pretrainedmodels import inceptionresnetv2


class CxAM(nn.Module):
    """Cross-layer Attention Module"""

    def __init__(self, in_channels, out_channels, reduction=8):
        super(CxAM, self).__init__()
        self.key_conv = nn.Conv2d(in_channels, out_channels // reduction, 1)
        self.query_conv = nn.Conv2d(in_channels, out_channels // reduction, 1)
        self.value_conv = nn.Conv2d(in_channels, in_channels, 1)
        self.sigmoid = nn.Sigmoid()
        self.avg = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        batch_size, C, width, height = x.size()
        proj_query = self.query_conv(x).view(batch_size, -1, width * height).permute(0, 2, 1)
        proj_key = self.key_conv(x).view(batch_size, -1, width * height)
        energy = torch.bmm(proj_query, proj_key).view(batch_size, width * height, width, height)
        attention = self.sigmoid(self.avg(energy).view(batch_size, -1, width, height))
        proj_value = self.value_conv(x)
        return proj_value * attention


class CnAM(nn.Module):
    """Cross-feature Attention Module"""

    def __init__(self, in_channels, out_channels, reduction=8):
        super(CnAM, self).__init__()
        self.proj_conv = nn.Conv2d(in_channels, out_channels // reduction, 1)
        self.context_conv = nn.Conv2d(in_channels, out_channels // reduction, 1)
        self.value_conv = nn.Conv2d(in_channels, in_channels, 1)
        self.sigmoid = nn.Sigmoid()
        self.avg = nn.AdaptiveAvgPool2d(1)

    def forward(self, context_feat, current_feat):
        # 自动尺寸对齐
        if context_feat.size()[-2:] != current_feat.size()[-2:]:
            current_feat = F.interpolate(current_feat, size=context_feat.shape[-2:],
                                         mode='bilinear', align_corners=True)

        batch_size, C, width, height = context_feat.size()
        proj_query = self.proj_conv(context_feat).view(batch_size, -1, width * height).permute(0, 2, 1)
        proj_key = self.context_conv(context_feat).view(batch_size, -1, width * height)
        energy = torch.bmm(proj_query, proj_key).view(batch_size, width * height, width, height)
        attention = self.sigmoid(self.avg(energy).view(batch_size, -1, width, height))
        proj_value = self.value_conv(current_feat)
        return proj_value * attention


class DenseBlock(nn.Module):
    def __init__(self, in_channels, mid_channels, out_channels, dilation_rate, dropout=0.1):
        super(DenseBlock, self).__init__()
        self.conv1x1 = nn.Conv2d(in_channels, mid_channels, 1)
        self.gn1 = nn.GroupNorm(32, mid_channels)
        self.conv3x3 = nn.Conv2d(mid_channels, out_channels, 3,
                                 padding=dilation_rate, dilation=dilation_rate)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = F.relu(self.gn1(self.conv1x1(x)), inplace=True)
        x = F.relu(self.conv3x3(x), inplace=True)
        return self.dropout(x)


class DenseAPP(nn.Module):
    def __init__(self, in_channels=2080, mid_channels=512, out_channels=256):
        super(DenseAPP, self).__init__()
        self.block1 = DenseBlock(in_channels, mid_channels, out_channels, 3)
        self.block2 = DenseBlock(in_channels + out_channels, mid_channels, out_channels, 6)
        self.block3 = DenseBlock(in_channels + 2 * out_channels, mid_channels, out_channels, 12)
        self.block4 = DenseBlock(in_channels + 3 * out_channels, mid_channels, out_channels, 18)
        self.block5 = DenseBlock(in_channels + 4 * out_channels, mid_channels, out_channels, 24)
        self.final_conv = nn.Sequential(
            nn.Conv2d(5 * out_channels, out_channels, 1),
            nn.GroupNorm(32, out_channels),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        feat1 = self.block1(x)
        x = torch.cat([feat1, x], dim=1)
        feat2 = self.block2(x)
        x = torch.cat([feat2, x], dim=1)
        feat3 = self.block3(x)
        x = torch.cat([feat3, x], dim=1)
        feat4 = self.block4(x)
        x = torch.cat([feat4, x], dim=1)
        feat5 = self.block5(x)
        out = torch.cat([feat1, feat2, feat3, feat4, feat5], dim=1)
        return self.final_conv(out)


class ACFPN(nn.Module):
    def __init__(self, norm_layer, num_filters=256):
        super(ACFPN, self).__init__()
        self.inception = inceptionresnetv2(num_classes=1001, pretrained=False)
        weight_path = 'D:/project/Citrus_data/code/DeblurGANv2-master/weights/inceptionresnetv2.pth'
        state_dict = torch.load(weight_path, weights_only=True)
        self.inception.load_state_dict(state_dict)

        # Encoder
        self.enc0 = self.inception.conv2d_1a
        self.enc1 = nn.Sequential(
            self.inception.conv2d_2a,
            self.inception.conv2d_2b,
            self.inception.maxpool_3a,
        )
        self.enc2 = nn.Sequential(
            self.inception.conv2d_3b,
            self.inception.conv2d_4a,
            self.inception.maxpool_5a,
        )
        self.enc3 = nn.Sequential(
            self.inception.mixed_5b,
            self.inception.repeat,
            self.inception.mixed_6a,
        )
        self.enc4 = nn.Sequential(
            self.inception.repeat_1,
            self.inception.mixed_7a,
        )

        # Context module
        self.dense_app = DenseAPP(in_channels=2080)

        # Attention modules
        self.cxam = CxAM(256, 256)
        self.cnam = CnAM(256, 256)

        # Lateral connections
        self.lateral4 = nn.Conv2d(2080, num_filters, 1)
        self.lateral3 = nn.Conv2d(1088, num_filters, 1)
        self.lateral2 = nn.Conv2d(192, num_filters, 1)
        self.lateral1 = nn.Conv2d(64, num_filters, 1)
        self.lateral0 = nn.Conv2d(32, num_filters // 2, 1)

        # Top-down path
        self.topdown1 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(inplace=True)
        )
        self.topdown2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(inplace=True)
        )
        self.topdown3 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(inplace=True)
        )

        # Freeze backbone
        for param in self.inception.parameters():
            param.requires_grad = False

    def unfreeze(self):
        for param in self.inception.parameters():
            param.requires_grad = True

    def forward(self, x):
        # Bottom-up
        enc0 = self.enc0(x)  # 1/1
        enc1 = self.enc1(enc0)  # 1/2
        enc2 = self.enc2(enc1)  # 1/4
        enc3 = self.enc3(enc2)  # 1/8
        enc4 = self.enc4(enc3)  # 1/16

        # Context
        dense_feat = self.dense_app(enc4)  # [B,256,H/16,W/16]

        # Lateral connections with precise alignment
        B, _, H, W = x.shape
        lateral4 = F.interpolate(self.lateral4(enc4), size=(H // 16, W // 16), mode='bilinear', align_corners=True)
        lateral3 = F.interpolate(self.lateral3(enc3), size=(H // 8, W // 8), mode='bilinear', align_corners=True)
        lateral2 = F.interpolate(self.lateral2(enc2), size=(H // 4, W // 4), mode='bilinear', align_corners=True)
        lateral1 = F.interpolate(self.lateral1(enc1), size=(H // 2, W // 2), mode='bilinear', align_corners=True)
        lateral0 = F.interpolate(self.lateral0(enc0), size=(H, W), mode='bilinear', align_corners=True)

        # Attention
        cxam_feat = self.cxam(dense_feat)
        cnam_feat = self.cnam(dense_feat, lateral4)
        p5 = cxam_feat + cnam_feat  # [B,256,H/16,W/16]

        # Top-down
        p4 = self.topdown1(lateral3 + F.interpolate(p5, size=(H // 8, W // 8), mode='bilinear', align_corners=True))
        p3 = self.topdown2(lateral2 + F.interpolate(p4, size=(H // 4, W // 4), mode='bilinear', align_corners=True))
        p2 = self.topdown3(lateral1 + F.interpolate(p3, size=(H // 2, W // 2), mode='bilinear', align_corners=True))

        return lateral0, p2, p3, p4, p5


class FPNHead(nn.Module):
    def __init__(self, in_channels, mid_channels, out_channels):
        super(FPNHead, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, mid_channels, 3, padding=1, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(mid_channels, out_channels, 3, padding=1, bias=False),
            nn.ReLU(inplace=True)
        )

    def forward(self, x):
        return self.block(x)


class FPNInception_ACFPN(nn.Module):
    def __init__(self, norm_layer, output_ch=3, num_filters=128, num_filters_fpn=256):
        super(FPNInception_ACFPN, self).__init__()
        self.fpn = ACFPN(norm_layer=norm_layer, num_filters=num_filters_fpn)

        # Heads
        self.head1 = FPNHead(num_filters_fpn, num_filters, num_filters)
        self.head2 = FPNHead(num_filters_fpn, num_filters, num_filters)
        self.head3 = FPNHead(num_filters_fpn, num_filters, num_filters)
        self.head4 = FPNHead(num_filters_fpn, num_filters, num_filters)

        # Smoothing
        self.smooth = nn.Sequential(
            nn.Conv2d(4 * num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU(inplace=True)
        )
        self.smooth2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters // 2, 3, padding=1),
            norm_layer(num_filters // 2),
            nn.ReLU(inplace=True)
        )

        # Output
        self.final = nn.Conv2d(num_filters // 2, output_ch, 3, padding=1)

    def unfreeze(self):
        self.fpn.unfreeze()

    def forward(self, x):
        # Input check
        assert x.size(2) % 32 == 0 and x.size(3) % 32 == 0, "Input size must be divisible by 32"
        B, C, H, W = x.shape

        # Get features
        map0, map1, map2, map3, map4 = self.fpn(x)

        # Process features with exact size matching
        map4 = F.interpolate(self.head4(map4), size=(H // 8, W // 8), mode='bilinear', align_corners=True)
        map3 = F.interpolate(self.head3(map3), size=(H // 4, W // 4), mode='bilinear', align_corners=True)
        map2 = F.interpolate(self.head2(map2), size=(H // 2, W // 2), mode='bilinear', align_corners=True)
        map1 = F.interpolate(self.head1(map1), size=(H, W), mode='bilinear', align_corners=True)

        # Upsample all features to input size
        map4 = F.interpolate(map4, size=(H, W), mode='bilinear', align_corners=True)
        map3 = F.interpolate(map3, size=(H, W), mode='bilinear', align_corners=True)
        map2 = F.interpolate(map2, size=(H, W), mode='bilinear', align_corners=True)

        # Combine features
        combined = torch.cat([map4, map3, map2, map1], dim=1)
        smoothed = self.smooth(combined)

        # Final processing
        smoothed = F.interpolate(smoothed + map0, size=(H, W), mode='bilinear', align_corners=True)
        smoothed = self.smooth2(smoothed)

        # Output with residual
        output = torch.tanh(self.final(smoothed)) + x
        return torch.clamp(output, -1, 1)


if __name__ == "__main__":
    norm_layer = nn.BatchNorm2d
    model = FPNInception_ACFPN(norm_layer=norm_layer)

    # Test cases
    test_sizes = [256, 288, 320]
    for size in test_sizes:
        dummy_input = torch.randn(1, 3, size, size)
        print(f"\nTesting {size}x{size} input:")
        try:
            output = model(dummy_input)
            assert output.shape == dummy_input.shape
            print(f"✓ Passed! Input/Output shape: {dummy_input.shape}")
        except Exception as e:
            print(f"✗ Failed: {str(e)}")
            # Debug print
            print("Debug info:")
            print(f"Input shape: {dummy_input.shape}")
            map0, map1, map2, map3, map4 = model.fpn(dummy_input)
            print(f"map0 shape: {map0.shape}")
            print(f"map1 shape: {map1.shape}")
            print(f"map2 shape: {map2.shape}")
            print(f"map3 shape: {map3.shape}")
            print(f"map4 shape: {map4.shape}")