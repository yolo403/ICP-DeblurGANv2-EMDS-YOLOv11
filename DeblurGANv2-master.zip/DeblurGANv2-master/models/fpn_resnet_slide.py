import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.hub import load_state_dict_from_url


class HybridAttention(nn.Module):
    def __init__(self, embed_dim, num_heads, window_size):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.window_size = window_size
        self.head_dim = embed_dim // num_heads

        assert self.head_dim * num_heads == embed_dim, "embed_dim must be divisible by num_heads"

        # 线性投影层
        self.q_proj = nn.Conv2d(embed_dim, embed_dim, 1, bias=False)
        self.k_proj = nn.Conv2d(embed_dim, embed_dim, 1, bias=False)
        self.v_proj = nn.Conv2d(embed_dim, embed_dim, 1, bias=False)
        self.o_proj = nn.Conv2d(embed_dim, embed_dim, 1, bias=False)

    def forward(self, x, global_mask=None):
        batch_size, embed_dim, height, width = x.shape
        device = x.device

        # 生成默认全局掩码（若未提供）
        if global_mask is None:
            global_mask = torch.zeros((batch_size, height, width), device=device)

        # 展平为序列形式 [batch, seq_len=height*width, embed_dim]
        x_flat = x.flatten(2).transpose(1, 2)  # [batch, h*w, embed_dim]
        mask_flat = global_mask.flatten(1)  # [batch, h*w]

        # 计算 Q, K, V [batch, seq_len, embed_dim]
        Q = self.q_proj(x).flatten(2).transpose(1, 2)
        K = self.k_proj(x).flatten(2).transpose(1, 2)
        V = self.v_proj(x).flatten(2).transpose(1, 2)

        # 分割多头 [batch, num_heads, seq_len, head_dim]
        Q = Q.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        K = K.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        V = V.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)

        # 初始化注意力分数
        seq_len = height * width
        attn_scores = torch.full((batch_size, self.num_heads, seq_len, seq_len),
                                 float("-inf"), device=device)

        # 计算 Sliding Window Attention
        for i in range(seq_len):
            h_i, w_i = i // width, i % width
            # 计算当前像素的窗口范围
            h_start = max(0, h_i - self.window_size)
            h_end = min(height, h_i + self.window_size + 1)
            w_start = max(0, w_i - self.window_size)
            w_end = min(width, w_i + self.window_size + 1)

            # 收集窗口内所有像素的索引
            window_indices = []
            for h in range(h_start, h_end):
                for w in range(w_start, w_end):
                    window_indices.append(h * width + w)

            if window_indices:
                # 修正：确保 Q 和 K 的维度对齐 [batch, num_heads, 1, head_dim] x [batch, num_heads, head_dim, len(window_indices)]
                q = Q[:, :, i:i + 1, :]  # [batch, num_heads, 1, head_dim]
                k = K[:, :, window_indices, :]  # [batch, num_heads, len(window_indices), head_dim]
                attn_scores[:, :, i, window_indices] = torch.matmul(q, k.transpose(-2, -1)).squeeze(2)

        # 计算 Global Attention
        global_mask_expanded = mask_flat.unsqueeze(1).unsqueeze(1)  # [batch, 1, 1, seq_len]
        global_indices = global_mask_expanded.expand(-1, self.num_heads, seq_len, -1)
        global_attn_scores = torch.matmul(Q, K.transpose(-2, -1))  # 全局注意力分数 [batch, num_heads, seq_len, seq_len]

        # 合并全局和局部注意力
        attn_scores = torch.where(global_indices == 1, global_attn_scores, attn_scores)

        # 归一化
        attn_scores = attn_scores / (self.head_dim ** 0.5)
        attn_weights = F.softmax(attn_scores, dim=-1)

        # 加权求和
        output = torch.matmul(attn_weights, V)  # [batch, num_heads, seq_len, head_dim]
        output = output.transpose(1, 2).reshape(batch_size, seq_len, embed_dim)
        output = output.transpose(1, 2).view(batch_size, embed_dim, height, width)

        # 输出投影
        output = self.o_proj(output)
        return output


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, in_channel, out_channel, stride=1, downsample=None,
                 groups=1, width_per_group=64, norm_layer=nn.BatchNorm2d):
        super().__init__()
        width = int(out_channel * (width_per_group / 64.)) * groups
        self.conv1 = nn.Conv2d(in_channel, width, 1, stride=1, bias=False)
        self.bn1 = norm_layer(width)
        self.conv2 = nn.Conv2d(width, width, 3, stride=stride, padding=1, bias=False)
        self.bn2 = norm_layer(width)
        self.conv3 = nn.Conv2d(width, out_channel * self.expansion, 1, stride=1, bias=False)
        self.bn3 = norm_layer(out_channel * self.expansion)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample

    def forward(self, x):
        identity = x
        if self.downsample is not None:
            identity = self.downsample(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        out += identity
        return self.relu(out)


class ResNet(nn.Module):
    def __init__(self, block, blocks_num, num_classes=1000, include_top=True,
                 groups=1, width_per_group=64, norm_layer=nn.BatchNorm2d):
        super().__init__()
        self.include_top = include_top
        self.in_channel = 64
        self.groups = groups
        self.width_per_group = width_per_group

        self.conv1 = nn.Conv2d(3, self.in_channel, kernel_size=7, stride=2, padding=3, bias=False)
        self.bn1 = norm_layer(self.in_channel)
        self.relu = nn.ReLU(inplace=True)
        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)

        self.layer1 = self._make_layer(block, 64, blocks_num[0])
        self.layer2 = self._make_layer(block, 128, blocks_num[1], stride=2)
        self.layer3 = self._make_layer(block, 256, blocks_num[2], stride=2)
        self.layer4 = self._make_layer(block, 512, blocks_num[3], stride=2)

        if self.include_top:
            self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
            self.fc = nn.Linear(512 * block.expansion, num_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')

    def _make_layer(self, block, channel, block_num, stride=1):
        downsample = None
        if stride != 1 or self.in_channel != channel * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.in_channel, channel * block.expansion, 1, stride=stride, bias=False),
                nn.BatchNorm2d(channel * block.expansion))
        layers = []
        layers.append(block(self.in_channel, channel, stride=stride, downsample=downsample,
                            groups=self.groups, width_per_group=self.width_per_group))
        self.in_channel = channel * block.expansion
        for _ in range(1, block_num):
            layers.append(block(self.in_channel, channel, groups=self.groups,
                                width_per_group=self.width_per_group))
        return nn.Sequential(*layers)

    def forward(self, x):
        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)
        x = self.maxpool(x)

        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)

        if self.include_top:
            x = self.avgpool(x)
            x = torch.flatten(x, 1)
            x = self.fc(x)
        return x


def resnet101(num_classes=1000, include_top=True, pretrained=False, norm_layer=nn.BatchNorm2d):
    model = ResNet(Bottleneck, [3, 4, 23, 3], num_classes=num_classes,
                   include_top=include_top, norm_layer=norm_layer)
    if pretrained:
        state_dict = load_state_dict_from_url(
            "https://download.pytorch.org/models/resnet101-5d3b4d8f.pth",
            progress=True)
        model.load_state_dict(state_dict, strict=False)
    return model


class FPN(nn.Module):
    def __init__(self, num_filters=256, pretrained=True, norm_layer=nn.BatchNorm2d,
                 use_attention=False, embed_dim=256, num_heads=8, window_size=3):
        super().__init__()
        self.use_attention = use_attention
        backbone = resnet101(pretrained=pretrained, norm_layer=norm_layer)

        # 特征提取层
        self.enc0 = nn.Sequential(backbone.conv1, backbone.bn1, backbone.relu, backbone.maxpool)
        self.enc1 = backbone.layer1  # 256
        self.enc2 = backbone.layer2  # 512
        self.enc3 = backbone.layer3  # 1024
        self.enc4 = backbone.layer4  # 2048

        # 侧向连接
        self.lateral4 = nn.Conv2d(2048, num_filters, 1)
        self.lateral3 = nn.Conv2d(1024, num_filters, 1)
        self.lateral2 = nn.Conv2d(512, num_filters, 1)
        self.lateral1 = nn.Conv2d(256, num_filters, 1)

        # 自上而下路径
        self.smooth4 = nn.Conv2d(num_filters, num_filters, 3, padding=1)
        self.smooth3 = nn.Conv2d(num_filters, num_filters, 3, padding=1)
        self.smooth2 = nn.Conv2d(num_filters, num_filters, 3, padding=1)

        # 注意力模块
        if self.use_attention:
            self.attn1 = HybridAttention(embed_dim, num_heads, window_size)
            self.attn2 = HybridAttention(embed_dim, num_heads, window_size)
            self.attn3 = HybridAttention(embed_dim, num_heads, window_size)
            self.attn4 = HybridAttention(embed_dim, num_heads, window_size)
            self.attn5 = HybridAttention(embed_dim, num_heads, window_size)

    def forward(self, x):
        # 自底向上
        c1 = self.enc0(x)  # [1, 64, H/2, W/2]
        c2 = self.enc1(c1)  # [1, 256, H/4, W/4]
        c3 = self.enc2(c2)  # [1, 512, H/8, W/8]
        c4 = self.enc3(c3)  # [1, 1024, H/16, W/16]
        c5 = self.enc4(c4)  # [1, 2048, H/32, W/32]

        # 自顶向下 + 侧向连接
        p5 = self.lateral4(c5)  # [1, 256, H/32, W/32]
        p4 = self.smooth4(F.interpolate(p5, size=c4.shape[-2:]) + self.lateral3(c4))
        p3 = self.smooth3(F.interpolate(p4, size=c3.shape[-2:]) + self.lateral2(c3))
        p2 = self.smooth2(F.interpolate(p3, size=c2.shape[-2:]) + self.lateral1(c2))
        p1 = F.interpolate(p2, size=c1.shape[-2:])

        # 应用注意力
        if self.use_attention:
            # 示例：对 p3 应用注意力（其他层类似）
            _, _, h, w = p3.shape
            global_mask = torch.zeros(1, h, w, device=x.device)  # 实际使用时需自定义
            p3 = self.attn3(p3, global_mask)

        return p1, p2, p3, p4, p5


class FPNResNet101_slide(nn.Module):
    def __init__(self, output_ch=3, num_filters=128, num_filters_fpn=256,
                 use_attention=False, norm_layer=nn.BatchNorm2d, **attention_kwargs):
        super().__init__()
        self.fpn = FPN(num_filters=num_filters_fpn, norm_layer=norm_layer,
                       use_attention=use_attention, **attention_kwargs)

        # FPNHead 定义
        def make_fpn_head():
            return nn.Sequential(
                nn.Conv2d(num_filters_fpn, num_filters, 3, padding=1),
                norm_layer(num_filters),
                nn.ReLU(),
                nn.Conv2d(num_filters, num_filters, 3, padding=1),
                norm_layer(num_filters),
                nn.ReLU(),
            )

        self.head1 = make_fpn_head()
        self.head2 = make_fpn_head()
        self.head3 = make_fpn_head()
        self.head4 = make_fpn_head()
        self.head5 = make_fpn_head()

        # 特征融合
        self.smooth = nn.Sequential(
            nn.Conv2d(5 * num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )

        # 输出层
        self.final_conv = nn.Sequential(
            nn.Conv2d(num_filters, num_filters // 2, 3, padding=1),
            norm_layer(num_filters // 2),
            nn.ReLU(),
            nn.Conv2d(num_filters // 2, output_ch, 3, padding=1),
            nn.Tanh()
        )

    def forward(self, x):
        p1, p2, p3, p4, p5 = self.fpn(x)

        # 处理每层特征
        h1 = F.interpolate(self.head1(p1), size=x.shape[-2:], mode='bilinear')
        h2 = F.interpolate(self.head2(p2), size=x.shape[-2:], mode='bilinear')
        h3 = F.interpolate(self.head3(p3), size=x.shape[-2:], mode='bilinear')
        h4 = F.interpolate(self.head4(p4), size=x.shape[-2:], mode='bilinear')
        h5 = F.interpolate(self.head5(p5), size=x.shape[-2:], mode='bilinear')

        # 融合 + 输出
        fused = torch.cat([h1, h2, h3, h4, h5], dim=1)
        smoothed = self.smooth(fused)
        output = self.final_conv(smoothed) + x
        return torch.clamp(output, -1, 1)

    def freeze(self):
        for param in self.parameters():
            param.requires_grad = False

    def unfreeze(self):
        for param in self.parameters():
            param.requires_grad = True


# 测试代码
if __name__ == "__main__":
    model = FPNResNet101_slide(
        output_ch=3,
        use_attention=True,
        embed_dim=256,
        num_heads=8,
        window_size=3
    )
    input_tensor = torch.randn(1, 3, 256, 256)
    output = model(input_tensor)
    print(f"Input shape: {input_tensor.shape}")
    print(f"Output shape: {output.shape}")
    print(f"Total parameters: {sum(p.numel() for p in model.parameters()) / 1e6:.2f}M")
