import torch
import torch.nn as nn
from timm.models.layers import DropPath, trunc_normal_
from functools import partial
from typing import List
from torch import Tensor
import copy
import os


class Partial_conv3(nn.Module):
    def __init__(self, dim, n_div, forward):
        super().__init__()
        self.dim_conv3 = dim // n_div
        self.dim_untouched = dim - self.dim_conv3
        self.partial_conv3 = nn.Conv2d(self.dim_conv3, self.dim_conv3, 3, 1, 1, bias=False)

        if forward == 'slicing':
            self.forward = self.forward_slicing
        elif forward == 'split_cat':
            self.forward = self.forward_split_cat
        else:
            raise NotImplementedError

    def forward_slicing(self, x: Tensor) -> Tensor:
        x = x.clone()
        x[:, :self.dim_conv3, :, :] = self.partial_conv3(x[:, :self.dim_conv3, :, :])
        return x

    def forward_split_cat(self, x: Tensor) -> Tensor:
        x1, x2 = torch.split(x, [self.dim_conv3, self.dim_untouched], dim=1)
        x1 = self.partial_conv3(x1)
        x = torch.cat((x1, x2), 1)
        return x


class MLPBlock(nn.Module):
    def __init__(self, dim, n_div, mlp_ratio, drop_path,
                 layer_scale_init_value, norm_layer, act_layer, pconv_fw_type):
        super().__init__()
        self.dim = dim
        self.mlp_ratio = mlp_ratio
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Conv2d(dim, mlp_hidden_dim, 1, bias=False),
            norm_layer(mlp_hidden_dim),
            act_layer(),
            nn.Conv2d(mlp_hidden_dim, dim, 1, bias=False)
        )

        self.spatial_mixing = Partial_conv3(dim, n_div, pconv_fw_type)

        if layer_scale_init_value > 0:
            self.layer_scale = nn.Parameter(layer_scale_init_value * torch.ones(dim))
            self.forward = self.forward_layer_scale
        else:
            self.forward = self.forward

    def forward(self, x):
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(self.mlp(x))
        return x

    def forward_layer_scale(self, x):
        shortcut = x
        x = self.spatial_mixing(x)
        x = shortcut + self.drop_path(self.layer_scale.unsqueeze(-1).unsqueeze(-1) * self.mlp(x))
        return x


class BasicStage(nn.Module):
    def __init__(self, dim, depth, n_div, mlp_ratio, drop_path,
                 layer_scale_init_value, norm_layer, act_layer, pconv_fw_type):
        super().__init__()
        self.blocks = nn.Sequential(*[
            MLPBlock(
                dim=dim,
                n_div=n_div,
                mlp_ratio=mlp_ratio,
                drop_path=drop_path[i],
                layer_scale_init_value=layer_scale_init_value,
                norm_layer=norm_layer,
                act_layer=act_layer,
                pconv_fw_type=pconv_fw_type
            ) for i in range(depth)
        ])

    def forward(self, x):
        return self.blocks(x)


class PatchEmbed(nn.Module):
    def __init__(self, patch_size, patch_stride, in_chans, embed_dim, norm_layer):
        super().__init__()
        self.proj = nn.Conv2d(in_chans, embed_dim, patch_size, stride=patch_stride, bias=False)
        self.norm = norm_layer(embed_dim) if norm_layer else nn.Identity()

    def forward(self, x):
        return self.norm(self.proj(x))


class PatchMerging(nn.Module):
    def __init__(self, patch_size2, patch_stride2, dim, norm_layer):
        super().__init__()
        self.reduction = nn.Conv2d(dim, 2 * dim, patch_size2, stride=patch_stride2, bias=False)
        self.norm = norm_layer(2 * dim) if norm_layer else nn.Identity()

    def forward(self, x):
        return self.norm(self.reduction(x))


class FasterNet(nn.Module):
    def __init__(self, in_chans=3, num_classes=1000, embed_dim=96,
                 depths=(1, 2, 8, 2), mlp_ratio=2., n_div=4,
                 patch_size=4, patch_stride=4, patch_size2=2, patch_stride2=2,
                 norm_layer='BN', act_layer='RELU', fork_feat=True, pretrained=None):

        super().__init__()
        norm_layer = nn.BatchNorm2d if norm_layer == 'BN' else None
        act_layer = partial(nn.ReLU, inplace=True) if act_layer == 'RELU' else nn.GELU

        self.patch_embed = PatchEmbed(patch_size, patch_stride, in_chans, embed_dim, norm_layer)

        dpr = [x.item() for x in torch.linspace(0, 0.1, sum(depths))]

        stages = []
        for i in range(len(depths)):
            stages.append(BasicStage(
                dim=int(embed_dim * 2 ** i),
                depth=depths[i],
                n_div=n_div,
                mlp_ratio=mlp_ratio,
                drop_path=dpr[sum(depths[:i]):sum(depths[:i + 1])],
                layer_scale_init_value=0,
                norm_layer=norm_layer,
                act_layer=act_layer,
                pconv_fw_type='split_cat'
            ))
            if i < len(depths) - 1:
                stages.append(PatchMerging(
                    patch_size2, patch_stride2,
                    int(embed_dim * 2 ** i), norm_layer
                ))

        self.stages = nn.Sequential(*stages)
        self.fork_feat = fork_feat
        self.out_indices = [0, 2, 4, 6]

        for i, idx in enumerate(self.out_indices):
            layer = norm_layer(int(embed_dim * 2 ** i))
            self.add_module(f'norm{idx}', layer)

        self.apply(self._init_weights)
        if pretrained:
            self._load_pretrained(pretrained)

    def _init_weights(self, m):
        if isinstance(m, (nn.Linear, nn.Conv2d)):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
            nn.init.constant_(m.weight, 1)
            nn.init.constant_(m.bias, 0)

    def forward(self, x):
        x = self.patch_embed(x)
        outs = []
        for i, stage in enumerate(self.stages):
            x = stage(x)
            if self.fork_feat and i in self.out_indices:
                norm = getattr(self, f'norm{i}')
                outs.append(norm(x))
        return outs


class FPNHead(nn.Module):
    def __init__(self, num_in, num_mid, num_out):
        super().__init__()
        self.block0 = nn.Conv2d(num_in, num_mid, 3, padding=1, bias=False)
        self.block1 = nn.Conv2d(num_mid, num_out, 3, padding=1, bias=False)

    def forward(self, x):
        x = nn.functional.relu(self.block0(x), inplace=True)
        x = nn.functional.relu(self.block1(x), inplace=True)
        return x


class FPNFasterNet(nn.Module):
    def __init__(self, norm_layer=nn.BatchNorm2d, output_ch=3,
                 num_filters=64, num_filters_fpn=128, pretrained=True):
        super().__init__()

        self.fpn = FasterFPN(num_filters_fpn, norm_layer, pretrained)

        self.head1 = FPNHead(num_filters_fpn, num_filters, num_filters)
        self.head2 = FPNHead(num_filters_fpn, num_filters, num_filters)
        self.head3 = FPNHead(num_filters_fpn, num_filters, num_filters)
        self.head4 = FPNHead(num_filters_fpn, num_filters, num_filters)

        self.smooth = nn.Sequential(
            nn.Conv2d(4 * num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )
        self.smooth2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters // 2, 3, padding=1),
            norm_layer(num_filters // 2),
            nn.ReLU()
        )
        self.final = nn.Conv2d(num_filters // 2, output_ch, 3, padding=1)

    def forward(self, x):
        map0, map1, map2, map3, map4 = self.fpn(x)

        map4 = nn.functional.interpolate(self.head4(map4), scale_factor=8, mode='nearest')
        map3 = nn.functional.interpolate(self.head3(map3), scale_factor=4, mode='nearest')
        map2 = nn.functional.interpolate(self.head2(map2), scale_factor=2, mode='nearest')
        map1 = nn.functional.interpolate(self.head1(map1), scale_factor=1, mode='nearest')

        smoothed = self.smooth(torch.cat([map4, map3, map2, map1], dim=1))
        smoothed = nn.functional.interpolate(smoothed, scale_factor=2, mode='nearest')
        smoothed = self.smooth2(smoothed + map0)
        smoothed = nn.functional.interpolate(smoothed, scale_factor=2, mode='nearest')

        final = self.final(smoothed)
        return torch.clamp(torch.tanh(final) + x, -1, 1)


class FasterFPN(nn.Module):
    def __init__(self, num_filters=128, norm_layer=nn.BatchNorm2d, pretrained=True):
        super().__init__()
        self.backbone = FasterNet(fork_feat=True, pretrained=pretrained, norm_layer='BN')

        if pretrained:
            for param in self.backbone.parameters():
                param.requires_grad = False

        # Get channel dimensions
        dummy = torch.rand(1, 3, 64, 64)
        feats = self.backbone(dummy)
        channels = [f.shape[1] for f in feats]

        # Lateral connections
        self.lateral0 = nn.Conv2d(channels[0], num_filters // 2, 1, bias=False)
        self.lateral1 = nn.Conv2d(channels[1], num_filters, 1, bias=False)
        self.lateral2 = nn.Conv2d(channels[2], num_filters, 1, bias=False)
        self.lateral3 = nn.Conv2d(channels[3], num_filters, 1, bias=False)

        # Top-down path
        self.td1 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )
        self.td2 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )
        self.td3 = nn.Sequential(
            nn.Conv2d(num_filters, num_filters, 3, padding=1),
            norm_layer(num_filters),
            nn.ReLU()
        )

    def forward(self, x):
        feats = self.backbone(x)

        l0 = self.lateral0(feats[0])
        l1 = self.lateral1(feats[1])
        l2 = self.lateral2(feats[2])
        l3 = self.lateral3(feats[3])

        m4 = l3
        m3 = self.td1(l2 + nn.functional.interpolate(m4, scale_factor=2, mode='nearest'))
        m2 = self.td2(l1 + nn.functional.interpolate(m3, scale_factor=2, mode='nearest'))
        m1 = self.td3(l0 + nn.functional.interpolate(m2, scale_factor=2, mode='nearest'))

        return l0, m1, m2, m3, m4